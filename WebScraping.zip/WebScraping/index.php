<?php
include "simple_html_dom.php";
if(isset($_POST['submit']))
{
    $url=$_GET['url'];
}
$productlist=array();
$header=array();
$filename="userdata.csv";
$csv_file=fopen($filename,"w");
$html_dom_parser=file_get_html($url);
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename=$filename;');
$header_element=$html_dom_parser->find('table thead th');
foreach ($header_element as $header->text()) 
{
  array_push($header,$header->text());
}
fputcsv($csv_file,$header);

$body_element=$html_dom_parser->find('table tbody tr');
foreach ($body_element as $body_data) 
{
  $title=$body_data->findOne()->getAttributes("")->innertext();
  $description=$body_data->findOne()->getAttributes("")->innertext();
  $category=$body_data->findOne()->getAttributes("")->innertext();
  $price=$body_data->findOne()->getAttributes("")->innertext();
  $sale_price=$body_data->findOne()->getAttributes("")->innertext();
  $url=$body_data->findOne()->getAttributes("")->innertext();
  $imageurl=$body_data->findOne()->getAttributes("")->innertext();

  $body_data_array=array(
  "Title"=$title, 
  "Description"=$description, 
  "Category"=$category, 
  "Price"=$price, 
  "Sale_Price"=$sale_price, 
  "Url"=$url, 
  "ImageUrl"=$imageurl 
  );

  $productlist[]=$body_data_array;

}

foreach($productlist as $product)
{
  fputcsv($csv_file,$product);
}

fclose($csv_file);
echo $csv_file; 
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crawl-Web Scraping</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body>
    <br><br>
    <div class="text-center">
    <center> 
    <div class="card" style="width: 18rem;">
    <div class="card-body">
    <h5 class="card-title">Welcome To Login</h5>
    <form  action="index.php" method="POST">
    <label>Enter The Website url:</label><br><br>
    <input type="text" name="url" placeholder="Enter Website Url"><br><br>  
    <input type="submit" name="submit" value="Crawl"><br> 
    </form>
    </div>
    </div>
    </center> 
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
  </body>
</html>