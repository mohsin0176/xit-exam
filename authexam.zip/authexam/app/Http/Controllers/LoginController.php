<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use App\Models\Login;
use Session;

class LoginController extends Controller
{
    public function index(Request $request) 
     {

         $rule= ([
                'username' => 'required|min:0|max:5',
                'password' => 'required|min:0|max:35'
                ]);
         $cm=   ([
                'username.required' => ' The username field is required.',
    			'username.min' => ' The username must be at least 0 characters.',
    			'username.max' => ' The username may not be greater than 5 characters.',
    			'password.required' => ' The password field is required.',
    			'password.min' => ' The pssword filed at least 0 characters.',
    			'password.max' => ' The  pssword filed at least 5 characters.'
                ]);
         $request->validate($rule,$cm);
         $username=$request->username;
         $password=$request->password;
         $role=$request->role;
         $result=Login::where('username',$username)->where('password',$password)->where('role',$role)->count();
         if($result<0){  return redirect('/login')->withSuccess('Welcome To Login Module Successfully');  }
         if($result>0 && $role='admin'){  return redirect('/admin')->withSuccess('Login To Admin Module Successfully');  }
         if($result>0 && $role='user') {  return redirect('/user')->withSuccess('Login To User Module Successfully');    }         

      

     }


     public function welcome() {
        return view('login');
     }

    
}
